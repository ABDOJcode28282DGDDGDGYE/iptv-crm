import Link from 'next/link';

const Sidebar = () => {
  return (
    <div className="flex flex-col w-64 bg-gray-800 text-white">
      <div className="flex items-center justify-center h-16 bg-gray-900">
        <span className="text-xl font-semibold">IPTV CRM</span>
      </div>
      <nav className="flex-1 px-2 py-4 space-y-2">
        <Link href="/">
          <a className="block px-4 py-2 rounded-md hover:bg-gray-700">Dashboard</a>
        </Link>
        <Link href="/customers">
          <a className="block px-4 py-2 rounded-md hover:bg-gray-700">Customers</a>
        </Link>
        <Link href="/orders">
          <a className="block px-4 py-2 rounded-md hover:bg-gray-700">Orders</a>
        </Link>
        <Link href="/subscriptions">
          <a className="block px-4 py-2 rounded-md hover:bg-gray-700">Subscriptions</a>
        </Link>
        <Link href="/payments">
          <a className="block px-4 py-2 rounded-md hover:bg-gray-700">Payments</a>
        </Link>
        <Link href="/tickets">
          <a className="block px-4 py-2 rounded-md hover:bg-gray-700">Tickets</a>
        </Link>
        <Link href="/settings">
          <a className="block px-4 py-2 rounded-md hover:bg-gray-700">Settings</a>
        </Link>
      </nav>
    </div>
  );
};

export default Sidebar;