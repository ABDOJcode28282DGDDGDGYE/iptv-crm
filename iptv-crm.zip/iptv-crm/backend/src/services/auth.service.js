const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
// const User = require('../models/user.model'); // سننشئ هذا لاحقاً

exports.registerUser = async (userData) => {
    // Here you would hash the password and save the user to the database
    // For now, let's simulate
    if (userData.password.length < 6) {
        throw new Error('Password must be at least 6 characters long');
    }
    const hashedPassword = await bcrypt.hash(userData.password, 10);
    const newUser = { ...userData, password: hashedPassword, id: Date.now() }; // Simulate
    // await User.create(newUser);
    return newUser;
};

exports.loginUser = async (email, password) => {
    // Here you would fetch the user from the database and compare passwords
    // For now, let's simulate
    const user = { id: 1, email: 'test@example.com', password: '$2a$10$abcdefghijklmnopqrstuvw.xyz', role: 'Admin' }; // Simulated user

    if (!user || user.email !== email) {
        throw new Error('Invalid credentials');
    }

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
        throw new Error('Invalid credentials');
    }

    const token = jwt.sign({ id: user.id, role: user.role }, process.env.JWT_SECRET, { expiresIn: '1h' });
    return { token, user: { id: user.id, email: user.email, role: user.role } };
};