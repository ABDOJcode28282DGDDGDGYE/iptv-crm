// backend/src/app.js
require('dotenv').config(); // Load environment variables from .env file

const express = require('express');
const app = express();
const PORT = process.env.PORT || 5231;

// Middleware to parse JSON bodies
app.use(express.json());

// Basic route
app.get('/', (req, res) => {
  res.send('IPTV CRM Backend is running!');
  app.use('/api/auth', authRoutes);
app.use('/api/customers', customerRoutes);
});


// ... (previous app.js content)

const { connectDB } = require('./config/database'); // Import connectDB function

// ... (previous app.js content)

// Connect to the database
connectDB();

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});