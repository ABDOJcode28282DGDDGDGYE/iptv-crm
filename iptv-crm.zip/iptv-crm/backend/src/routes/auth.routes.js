const express = require('express');
const router = express.Router();
const authController = require('../controllers/auth.controller'); // سننشئ هذا لاحقاً

// Public routes
router.post('/register', authController.register);
router.post('/login', authController.login);

// Protected route example (requires authentication)
// router.get('/profile', authMiddleware, authController.getProfile);

module.exports = router;